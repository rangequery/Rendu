/*
 * status_json.ino
 * ESP32 : capteurs + regulation + status JSON au format G. Menez (slide 28)
 *
 * Envoie UNE ligne JSON compacte toutes les "sp" secondes sur le port serie
 * (9600 bauds) => a utiliser avec le flow Node-RED for_graph.json
 *
 * Bibliotheques : ArduinoJson (B. Blanchon), OneWire, DallasTemperature
 * Fichiers du dossier : status_json.ino, makejson.h, makejson.cpp
 *
 * IMPORTANT : rien d'autre que du JSON ne doit sortir sur Serial,
 * sinon le noeud "json" de Node-RED leve une erreur a chaque ligne parasite.
 */
#include <WiFi.h>
#include "OneWire.h"
#include "DallasTemperature.h"
#include "makejson.h"

/* ---- Brochage : A ADAPTER a ton montage du TP regulateur ---- */
#define TEMP_PIN   23   // DS18B20 (bus OneWire)
#define LIGHT_PIN  A5   // photoresistance : ADC1_CHANNEL_5 = GPIO 33
#define HEAT_PIN   19   // LED rouge  = "chauffage"
#define COLD_PIN   21   // LED verte  = "climatisation"
#define FAN_PIN    27   // ventilateur (PWM)

/* ---- Detection "feu" : A ADAPTER (semantique precisee dans un prochain cours) ---- */
#define FIRE_LIGHT_THRESHOLD 3500   // luminosite brute, ADC 12 bits (0..4095)

OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);

esp_model em;   // TOUT l'etat de l'ESP est dans cette struct

/* 1) Lecture des capteurs -> struct (valeurs NUMERIQUES, pas des String) */
void read_sensors() {
  tempSensor.requestTemperatures();
  float t = tempSensor.getTempCByIndex(0);
  if (t != DEVICE_DISCONNECTED_C) {   // capteur debranche => -127 : on garde la derniere valeur
    em.temperature = t;
  }
  em.luminosity = analogRead(LIGHT_PIN);
}

/* 2) Regulation : met a jour l'etat dans la struct ET pilote les actionneurs */
void regulate() {
  if (em.temperature < em.lowThreshold) {          // trop froid  -> on chauffe
    em.heaterState = true;
    em.coolerState = false;
  } else if (em.temperature > em.highThreshold) {  // trop chaud  -> on refroidit
    em.heaterState = false;
    em.coolerState = true;
  } else {                                          // dans la plage -> rien
    em.heaterState = false;
    em.coolerState = false;
  }
  // "RUNNING" quand un actionneur travaille, "HALT" sinon
  em.regulationState = em.heaterState || em.coolerState;

  // Ventilo proportionnel a l'ecart au seuil haut (PWM 0..255)
  if (em.coolerState) {
    em.fanSpeed = constrain((int)(100 + (em.temperature - em.highThreshold) * 50), 0, 255);
  } else {
    em.fanSpeed = 0;
  }

  em.fireDetected = (em.luminosity > FIRE_LIGHT_THRESHOLD);

  digitalWrite(HEAT_PIN, em.heaterState ? HIGH : LOW);
  digitalWrite(COLD_PIN, em.coolerState ? HIGH : LOW);
  analogWrite(FAN_PIN, em.fanSpeed);
}

/* 3) Serialisation + emission : UNE ligne compacte terminee par \n */
void report() {
  StaticJsonDocument<1500> doc = makeJSON_fromstatus(&em);
  serializeJson(doc, Serial);   // PAS serializeJsonPretty : Node-RED decoupe sur \n
  Serial.println();
}

void setup() {
  Serial.begin(9600);

  pinMode(HEAT_PIN, OUTPUT);
  pinMode(COLD_PIN, OUTPUT);
  pinMode(FAN_PIN, OUTPUT);

  tempSensor.begin();

  // Reseau : pas encore de connexion WiFi -> "NOP", sauf la MAC lisible sans connexion
  WiFi.mode(WIFI_STA);
  em.MAC      = WiFi.macAddress();
  em.WiFiSSID = "NOP";
  em.IP       = "0.0.0.0";
}

void loop() {
  read_sensors();
  regulate();
  report();
  delay(em.target_sp * 1000UL);   // periode = champ "sp" du modele (2 s)
}
