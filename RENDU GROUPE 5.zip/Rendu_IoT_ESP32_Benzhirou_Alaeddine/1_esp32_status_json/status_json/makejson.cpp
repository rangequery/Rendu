/*
 * Implementation du modele JSON de l'ESP (format impose par G. Menez, slide 28)
 * File : status_json/makejson.cpp
 *
 * Les cles sont inserees dans le MEME ordre que la slide 28
 * (ArduinoJson conserve l'ordre d'insertion).
 */
#include "makejson.h"

/* {"lat": ..., "lon": ...} */
StaticJsonDocument<1000> makeJSON_fromlocation(float lat, float lgn) {
  StaticJsonDocument<1000> doc;
  doc["lat"] = lat;
  doc["lon"] = lgn;
  return doc;
}

StaticJsonDocument<1500> makeJSON_fromstatus(esp_model *em) {
  StaticJsonDocument<1500> doc;

  /* ---- status : valeurs capteurs + etat du regulateur ---- */
  doc["status"]["temperature"] = em->temperature;                         // number
  doc["status"]["light"]       = em->luminosity;                          // number
  doc["status"]["regul"]       = em->regulationState ? "RUNNING" : "HALT"; // string
  doc["status"]["fire"]        = em->fireDetected;                        // boolean
  doc["status"]["heat"]        = em->heaterState ? "ON" : "OFF";          // string
  doc["status"]["cold"]        = em->coolerState ? "ON" : "OFF";          // string
  doc["status"]["fanspeed"]    = em->fanSpeed;                            // number

  /* ---- location : constantes ---- */
  doc["location"]["room"]    = em->room;
  doc["location"]["gps"]     = makeJSON_fromlocation(em->latitude, em->longitude);
  doc["location"]["address"] = em->address;

  /* ---- regul : seuils de regulation ----
     NB : sur la slide 28, lt=26 et ht=25.9 sont inverses par rapport
     a la struct. Ici lt = seuil BAS, ht = seuil HAUT (le sens logique). */
  doc["regul"]["lt"] = em->lowThreshold;
  doc["regul"]["ht"] = em->highThreshold;

  /* ---- info : constantes ---- */
  doc["info"]["ident"] = em->ident;
  doc["info"]["user"]  = em->user;
  doc["info"]["loc"]   = em->loc;

  /* ---- net : uptime en STRING (comme la slide), le reste en NOP pour l'instant ---- */
  doc["net"]["uptime"] = String(millis() / 1000);
  doc["net"]["ssid"]   = em->WiFiSSID;
  doc["net"]["mac"]    = em->MAC;
  doc["net"]["ip"]     = em->IP;

  /* ---- reporthost : constantes ---- */
  doc["reporthost"]["target_ip"]   = em->target_ip;
  doc["reporthost"]["target_port"] = em->target_port;
  doc["reporthost"]["sp"]          = em->target_sp;

  return doc;
}
