#ifndef MAKEJSONH
#define MAKEJSONH
/*
  Proposition of a (arduino side) model for the ESP
  File : status_json/makejson.h
  Base : header de G. Menez (slide 29) + bloc "info" ajoute
*/
#include <Arduino.h>
#include <ArduinoJson.h>

typedef struct {
  int luminosity;
  float temperature;

  const float highThreshold = 26.0;
  const float lowThreshold = 25.9;
  bool coolerState;     // "ON" : "OFF";
  bool heaterState;     // "ON" : "OFF";
  bool regulationState; // Regulation status : "RUNNING" or "HALT"
  bool fireDetected;
  int fanSpeed;

  // Résidence Newton, 2400 Route des Dolines, 06560 Valbonne, France
  const double latitude = 43.62454;
  const double longitude = 7.050628;
  char room[50] = "312";
  char address[200] = "Les lucioles";

  // Info (AJOUTE : absent du header du prof) -> constantes a personnaliser
  char ident[50] = "ESP32 Alae";
  char user[50]  = "Alae";
  char loc[50]   = "A Biot";

  // Network
  String WiFiSSID;
  String MAC;
  String IP;

  // Reporting
  String target_ip = "127.0.0.1";
  int target_port = 1880;
  int target_sp = 2;
} esp_model;

/* Make a JSON Doc from location GPS */
StaticJsonDocument<1000> makeJSON_fromlocation(float lat, float lgn);
/* Make a JSON Doc of the esp status */
StaticJsonDocument<1500> makeJSON_fromstatus(esp_model *em);

#endif
