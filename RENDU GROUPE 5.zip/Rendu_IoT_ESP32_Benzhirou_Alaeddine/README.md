# Rendu IoT ESP32 - JSON, validateur, dashboard
Benzhirou Alaeddine

## 1. ESP32 : status au format JSON impose (1_esp32_status_json/)
Sketch `status_json/status_json.ino` (+ `makejson.h`, `makejson.cpp`), bibliotheques ArduinoJson,
OneWire, DallasTemperature. L'ESP lit les capteurs, regule, puis envoie toutes les `sp` secondes
UNE ligne JSON compacte sur le port serie (9600 bauds), au format de la slide 28.

## 2. Validateur JSON (2_validateur_json/) - JavaScript / Ajv
    npm install
    node validate.js mon_status.json      # ou un dossier, ou "-" pour l'entree standard
    npm test                              # 125 cas de regression
    npm run redteam                       # 13 agents d'attaque, ~127 000 tentatives
Detail des choix (schema ferme, limites physiques, anti-doublons, Unicode, nombres...) : voir son README.

## 3. Dashboard Node-RED (3_dashboard_nodered/)
1. Palettes : `node-red-node-serialport` et `node-red-dashboard`.
2. Menu > Importer > `dashboard_esp32.json`, regler le port du noeud SerialUSB0, Deployer.
3. Ouvrir http://localhost:1880/ui
Chaine : serial in -> json -> garde (ignore les lignes parasites) -> jauges (temperature,
luminosite, ventilateur), courbes sur 1 h, voyants de regulation (regul / chauffage /
climatisation / feu, seuils), fiche identite & reseau.
Sans carte : activer le noeud "Simuler l'ESP (2 s)" (desactive par defaut).
