#!/usr/bin/env node
/*
 * test.js - Batterie de tests du validateur
 *   tests/valid_*.json -> DOIVENT etre acceptes
 *   tests/bad_*.json   -> DOIVENT etre rejetes
 * Usage : npm test   (ou : node test.js)
 * Ajoute tes propres cas : il suffit de deposer un fichier valid_xx.json ou bad_xx.json dans tests/
 */
"use strict";

const fs = require("fs");
const path = require("path");
const { validateFile } = require("./validate");

const DIR = path.join(__dirname, "tests");
const files = fs.readdirSync(DIR).filter((f) => f.endsWith(".json")).sort();

let ok = 0;
const ko = [];
for (const f of files) {
  const expectValid = f.startsWith("valid_");
  const r = validateFile(path.join(DIR, f));
  const pass = r.valid === expectValid;
  if (pass) ok++;
  else ko.push(f);
  const verdict = r.valid ? "accepte" : "rejete ";
  const why = r.valid
    ? (r.warnings[0] ? `(avertissement : ${r.warnings[0]})` : "")
    : `[${r.errors[0].layer}] ${r.errors[0].path ? r.errors[0].path + " : " : ""}${r.errors[0].message}`;
  console.log(`${pass ? "\u2705" : "\u274C"} ${verdict} ${f.padEnd(40)} ${why}`);
}

console.log(`\n${ok}/${files.length} verdicts corrects`);
if (ko.length) {
  console.log("A CORRIGER :", ko.join(", "));
  process.exit(1);
}
