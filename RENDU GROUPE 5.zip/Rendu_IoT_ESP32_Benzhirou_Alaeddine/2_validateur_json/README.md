# Validateur JSON du status ESP32 (Ajv)

Verifie qu'un JSON respecte le modele impose (slide 28, G. Menez) et rejette les faux.
Principe "fail closed" : au moindre doute, ou si une erreur inattendue survient, le JSON est REJETE.

## Installation
    npm install            (Node.js >= 18)

## Utilisation
    node validate.js mon_status.json            # un fichier
    node validate.js tests/                      # tout un dossier (.json, .JSON)
    cat status.json | node validate.js -         # entree standard
    node validate.js --sans-coherence f.json     # sans les 2 regles de coherence
    npm test                                     # 125 cas : valid_* acceptes, bad_* rejetes
    npm run redteam                              # 13 agents d'attaque en parallele (~127 000 attaques)

Code retour : 0 = valide, 1 = invalide, 2 = mauvaise utilisation (option inconnue, aucun fichier...).

## Les 5 couches
1. LECTURE  : fichier normal uniquement (pas /dev/urandom, FIFO, dossier), lecture bornee a 16 Ko
2. ENCODAGE : UTF-8 strict ; UTF-16/32 et octet nul (0x00) refuses ; BOM tolere avec avertissement
3. SYNTAXE  : JSON.parse (RFC 8259), verifie sur le corpus officiel JSONTestSuite
4. TEXTE BRUT : ce que JSON.parse accepte EN SILENCE
   - cles dupliquees, meme deguisees ("temp\u0065rature")
   - nombres arrondis a la lecture : le nombre ECRIT doit etre un arrondi correct de la valeur lue
     (calcul exact en BigInt). 1e999, 1e-400, 123.000000000000000001 refuses ;
     toute sortie de vrai serialiseur acceptee (JS, Python, ArduinoJson, printf %.Nf / %.Ng / %e).
   - surrogates UTF-16 isoles (I-JSON, RFC 7493)
5. SCHEMA   : Ajv strict, JSON Schema 2020-12 (esp_schema.json), aucune conversion de type

## Choix du schema
- Types identiques a l'instance de la slide 28 (uptime en texte, fire en booleen, heat/cold en "ON"/"OFF").
- Ensemble ferme : tout champ manquant OU en trop est refuse, a tous les niveaux.
- Limites physiques : DS18B20 -55..125 (rejette -127 = capteur debranche), light 0..4095 (ADC 12 bits),
  lat/lon, ports 1..65535, IPv4, MAC (ni nulle ni broadcast), IP cible ni 0.0.0.0 ni broadcast ni multicast.
- Longueurs max en OCTETS UTF-8 = tailles des buffers C de esp_model (room 49, address 199, ssid 32).
- Textes libres : lettres de l'alphabet latin (accents compris), chiffres 0-9, ponctuation, symboles,
  espace simple. Refuses : invisibles (zero-width, selecteurs de variante, remplissage hangul, braille vide),
  bidi ("Trojan Source"), controles, faux espaces, homoglyphes (cyrillique, grec, armenien, cherokee...),
  caracteres de compatibilite (pleine chasse, lettres/chiffres mathematiques, exposants, ligatures),
  chiffres non ASCII, accents orphelins ou empiles (zalgo).
- Coherence (desactivable avec --sans-coherence) : heat et cold jamais ON ensemble ;
  regul = HALT => aucun actionneur ON.
- Volontairement NON verifie, car l'instance du prof les contredit :
  lt < ht (slide : lt=26, ht=25.9) et fanspeed = 0 quand cold = OFF (slide : fanspeed=1234).
- Conforme a la norme : 1880.0 et 1.5e2 sont des entiers valides (JSON Schema compare des valeurs).

## Red team (redteam/)
13 agents lances en parallele, chacun avec une mission. Leurs verdicts attendus viennent d'un
oracle ecrit a la main (redteam/lib.js) SANS reutiliser le schema ni Ajv : un desaccord = un bug.
A01 syntaxe (JSONTestSuite) | A02 doublons | A03 types & structure | A04 bornes IEEE 754 |
A05 formats reseau | A06 Unicode (65 536 caracteres) | A07 encodage octet par octet | A08 nombres |
A09 pieges JavaScript (__proto__) | A10 differentiel (25 000 docs) | A11 coherence | A12 deni de service |
A13 API & ligne de commande. Le rapport est ecrit dans redteam/RAPPORT_REDTEAM.md.

## Reutilisation (TP5)
    const { validateText } = require("./validate");
    const r = validateText(payloadRecu);   // chaine OU Buffer -> { valid, errors, warnings }
