/* A03 - Types et structure : chaque champ recoit chaque type JSON possible ; chaque objet est
 *   remplace, vide, ampute, gonfle ; la racine prend toutes les formes. Aucune conversion tolereee. */
"use strict";
const { Agent, BASE, OBJECTS, LEAVES, docOk, docWith, clone, setPath, textWith } = require("./lib");
const A = new Agent("A03 Types & structure", "23 champs x 34 valeurs de tous types + objets amputes/gonfles/remplaces");
const VALUES = [0, 1, -1, 1.5, 25.9375, 123, 1880, 2, 4095, 65535, "1", "25.9375", "true", "false", "", " ", "ON", "OFF", "HALT",
  "RUNNING", "on", true, false, null, {}, [], [1], { v: 1 }, "NOP", "55", "AC:67:B2:37:C9:48", "192.168.1.45", "GM", "0"];
for (const leaf of LEAVES) for (const v of VALUES) A.check(`${leaf} = ${JSON.stringify(v)}`, textWith(leaf, v), docOk(docWith(leaf, v)));
for (const leaf of LEAVES) {
  const d = clone(BASE());
  const ks = leaf.split(".");
  delete ks.slice(0, -1).reduce((x, k) => x[k], d)[ks[ks.length - 1]];
  A.check(`${leaf} supprime`, JSON.stringify(d), false);
}
for (const obj of OBJECTS) {
  for (const extra of ["extra", "Temperature", "temperature ", " status", "", "0", "status", "lat"]) {
    const d = clone(BASE());
    const o = obj === "" ? d : obj.split(".").reduce((x, k) => x[k], d);
    if (Object.prototype.hasOwnProperty.call(o, extra)) continue;
    o[extra] = 1;
    A.check(`${obj || "(racine)"} + cle en trop ${JSON.stringify(extra)}`, JSON.stringify(d), false);
  }
  if (obj === "") continue;
  for (const v of [null, [], {}, "x", 1, true, [BASE()]]) A.check(`${obj} = ${JSON.stringify(v).slice(0, 15)}`, JSON.stringify(setPath(clone(BASE()), obj, v)), false);
}
for (const root of ["null", "true", "0", '"x"', "[]", "{}", `[${JSON.stringify(BASE())}]`, `{"status":${JSON.stringify(BASE())}}`]) A.check(`racine ${root.slice(0, 20)}`, root, false);
A.check("instance du prof", JSON.stringify(BASE()), true);
A.finish();
