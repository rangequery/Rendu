/* A06 - Unicode : TOUS les caracteres du plan multilingue de base (65 536) + echantillon des
 *   plans supplementaires, injectes au milieu, au debut et a la fin d'un texte libre.
 *   Cherche : invisibles, faux espaces, bidi, homoglyphes (cyrillique, grec, armenien,
 *   cherokee...), lettres/chiffres mathematiques, pleine chasse, zalgo, surrogates.        */
"use strict";
const { Agent, textOk, textWith, rint, pick } = require("./lib");
const A = new Agent("A06 Unicode", "65 536 caracteres du BMP + plans supplementaires, homoglyphes, invisibles, zalgo, NFKC");
const F = "info.user";
const cps = [];
for (let cp = 0; cp <= 0xffff; cp++) cps.push(cp);
for (let cp = 0x10000; cp <= 0x3ffff; cp += 61) cps.push(cp);
for (let cp = 0xe0000; cp <= 0xe01ef; cp++) cps.push(cp);
for (const cp of [0x1d400, 0x1d41a, 0x1d7ce, 0x1f600, 0x1f44d, 0x1f3fb, 0xf0000, 0x10fffd, 0x1d173, 0x1d17a]) cps.push(cp);
for (const cp of cps) {
  const c = String.fromCodePoint(cp);
  const v = "G" + c + "M";
  A.check(`U+${cp.toString(16).toUpperCase().padStart(4, "0")} au milieu`, textWith(F, v), textOk(v, 49));
}
for (const cp of [0x20, 0xa0, 0x200b, 0x2800, 0x3164, 0x301, 0x41, 0xe9, 0x430, 0x1d406, 0xff27, 0x202e, 0xfe0f, 0x34f]) {
  const c = String.fromCodePoint(cp);
  A.check(`U+${cp.toString(16)} au debut`, textWith(F, c + "GM"), textOk(c + "GM", 49));
  A.check(`U+${cp.toString(16)} a la fin`, textWith(F, "GM" + c), textOk("GM" + c, 49));
}
const SPECIAL = ["e\u0301", "\u0301e", "e\u0301\u0301", "e\u0301\u0301\u0301", "1\u0301", " \u0301", "G\u0301\u0302M", "Les lucioles",
  "Les luciolеs", "Lеs", "Lіvebox", "Livebօx", "ᎪBC", "𝐆𝐌", "ＧＭ", "ﬁle", "m²", "½", "Ⅻ", "…", "GM™", "ℂ", "\u2126", "Kelvin \u212A",
  "Москва", "Αθήνα", "Ꭺ", "GM😀", "👍🏻", "👨‍👩‍👧", "🇫🇷", "e\u0301".repeat(24), "é".repeat(24), "é".repeat(25), "a".repeat(49), "a".repeat(50),
  "😀".repeat(12), "😀".repeat(13), "\ud800", "a\udc00", "\udbff\udfff", "\ud83d\ude00"];
for (const v of SPECIAL) A.check(`texte ${JSON.stringify(v).slice(0, 30)}`, textWith(F, v), textOk(v, 49));
const POOL = ["a", "é", "e\u0301", " ", "1", "-", "’", "☀", "\u200b", "\u0435", "Ꭺ", "\u00a0", "\u3164", "𝐀", "Ａ", "\u0301", "٣", "\u2028", "\ufe0f"];
for (let i = 0; i < 4000; i++) {
  const v = Array.from({ length: rint(1, 12) }, () => pick(POOL)).join("");
  A.check(`aleatoire ${JSON.stringify(v)}`, textWith(F, v), textOk(v, 49));
}
A.finish();
