/* A05 - Formats reseau : IPv4, IP cible, MAC, uptime
 *   pieges classiques (zeros initiaux/octal, notations courtes "127.1", hexa "0x7f", IPv6,
 *   CIDR, retour a la ligne final, chiffres arabes ou pleine chasse, separateurs Cisco...)
 *   + 4000 chaines aleatoires par champ, jugees par un oracle ecrit sans expression reguliere */
"use strict";
const { Agent, CONTRACT, leafOk, textWith, rint, pick } = require("./lib");
const A = new Agent("A05 Formats reseau", "IPv4 / IP cible / MAC / uptime : pieges connus + 16 000 chaines aleatoires");
const IPS = ["192.168.1.45", "0.0.0.0", "255.255.255.255", "127.0.0.1", "10.0.0.1", "192.168.01.45", "010.0.0.1", "127.1", "127.0.1",
  "1.2.3.4.5", "1.2.3.", ".1.2.3", "1..2.3", "256.1.1.1", "1.1.1.256", "-1.1.1.1", "+1.1.1.1", " 1.1.1.1", "1.1.1.1 ", "1.1.1.1\n",
  "0x7f.0.0.1", "0177.0.0.1", "2130706433", "::1", "::ffff:127.0.0.1", "192.168.1.45/24", "192.168.1.45:1880", "١٩٢.١٦٨.١.١",
  "１９２.１６８.１.１", "192.168.1.4５", "1.1.1.1\u0000", "224.0.0.1", "239.255.255.255", "223.255.255.255", "240.0.0.1", "", "localhost"];
const MACS = ["AC:67:B2:37:C9:48", "ac:67:b2:37:c9:48", "Ac:67:B2:37:c9:48", "00:00:00:00:00:00", "FF:FF:FF:FF:FF:FF", "ff:FF:ff:FF:ff:FF",
  "AC-67-B2-37-C9-48", "AC67.B237.C948", "AC67B237C948", "AC:67:B2:37:C9", "AC:67:B2:37:C9:48:00", "AC:67:B2:37:C9:4", "AC:67:B2:37:C9:48\n",
  " AC:67:B2:37:C9:48", "AC:67:B2:37:C9:4G", "AC:67:B2:37:C9:４8", "AC::B2:37:C9:48", "AC:67:B2:37:C9:48:", "01:00:5E:00:00:01", ""];
const UPS = ["55", "0", "00", "055", "-5", "+5", " 5", "5 ", "5.0", "1e3", "0x10", "٥٥", "５５", "9999999999", "99999999999", "4294967295", "", "NOP", "5\n"];
for (const v of IPS) {
  A.check(`net.ip = ${JSON.stringify(v)}`, textWith("net.ip", v), leafOk(CONTRACT["net.ip"], v));
  A.check(`target_ip = ${JSON.stringify(v)}`, textWith("reporthost.target_ip", v), leafOk(CONTRACT["reporthost.target_ip"], v));
}
for (const v of MACS) A.check(`net.mac = ${JSON.stringify(v)}`, textWith("net.mac", v), leafOk(CONTRACT["net.mac"], v));
for (const v of UPS) A.check(`net.uptime = ${JSON.stringify(v)}`, textWith("net.uptime", v), leafOk(CONTRACT["net.uptime"], v));
const ALPHA = [..."0123456789.:abcdefABCDEF -/x\n", "٣", "１", "\u00A0"];
const gen = (n) => Array.from({ length: n }, () => (Math.random() < 0.7 ? pick([..."0123456789.:"]) : pick(ALPHA))).join("");
for (const leaf of ["net.ip", "reporthost.target_ip", "net.mac", "net.uptime"]) {
  for (let i = 0; i < 4000; i++) {
    let v = gen(rint(1, 18));
    if (leaf === "net.mac" && Math.random() < 0.5) v = Array.from({ length: 6 }, () => gen(2)).join(":");
    if (leaf.includes("ip") && Math.random() < 0.5) v = Array.from({ length: 4 }, () => String(rint(0, 300)).replace(/^/, Math.random() < 0.1 ? "0" : "")).join(".");
    A.check(`${leaf} = ${JSON.stringify(v)}`, textWith(leaf, v), leafOk(CONTRACT[leaf], v));
  }
}
A.finish();
