/* A10 - Test differentiel : 25 000 documents aleatoires mutes (0 a 3 mutations : valeurs,
 *   suppressions, ajouts, renommages, objets remplaces). Chaque verdict du validateur est
 *   compare a l'oracle INDEPENDANT (lib.js, ecrit a la main sans Ajv ni schema).
 *   Tout desaccord = un bug dans l'un des deux.                                              */
"use strict";
const { Agent, OBJECTS, LEAVES, docOk, randomValidDoc, rint, pick } = require("./lib");
const A = new Agent("A10 Differentiel", "25 000 documents mutes au hasard, verdict compare a un oracle independant");
const POOL = [0, -1, 1.5, 4095, 4096, 65535, 65536, -55, 125, 125.5, -55.5, 90, 91, -180, 181, 3600, 3601, "", " ", "ON", "OFF", "on", "HALT",
  "RUNNING", true, false, null, {}, [], "1", "55", "055", "0", "NOP", "GM", "GM ", "G\u200bM", "Lеs", "𝐆", "AC:67:B2:37:C9:48", "00:00:00:00:00:00",
  "192.168.1.45", "0.0.0.0", "224.0.0.1", "192.168.01.1", "é".repeat(25), "a".repeat(33), "e\u0301", "\u0301e", "Crème", "☀", "\ud800"];
const get = (d, p) => p.split(".").reduce((x, k) => (x !== null && typeof x === "object" ? x[k] : undefined), d);
for (let i = 0; i < 25000; i++) {
  const d = randomValidDoc();
  const n = rint(0, 3);
  for (let m = 0; m < n; m++) {
    const op = Math.random();
    if (op < 0.55) {
      const leaf = pick(LEAVES);
      const parent = get(d, leaf.split(".").slice(0, -1).join("."));
      if (parent && typeof parent === "object") parent[leaf.split(".").pop()] = pick(POOL);
    } else if (op < 0.65) {
      const leaf = pick(LEAVES);
      const parent = get(d, leaf.split(".").slice(0, -1).join("."));
      if (parent && typeof parent === "object") delete parent[leaf.split(".").pop()];
    } else if (op < 0.75) {
      const o = pick(OBJECTS);
      const t = o === "" ? d : get(d, o);
      if (t && typeof t === "object") t[pick(["x", "Temperature", "lat", "status", "__proto__x", ""])] = pick(POOL);
    } else if (op < 0.85) {
      const leaf = pick(LEAVES);
      const parent = get(d, leaf.split(".").slice(0, -1).join("."));
      const k = leaf.split(".").pop();
      if (parent && typeof parent === "object" && k in parent) { parent[k.toUpperCase()] = parent[k]; delete parent[k]; }
    } else if (op < 0.92) {
      const o = pick(OBJECTS.slice(1));
      const ks = o.split(".");
      const parent = ks.length === 1 ? d : get(d, ks.slice(0, -1).join("."));
      if (parent && typeof parent === "object") parent[ks[ks.length - 1]] = pick([null, [], "x", 1]);
    } else {
      if (d.status && typeof d.status === "object") { d.status.heat = pick(["ON", "OFF"]); d.status.cold = pick(["ON", "OFF"]); d.status.regul = pick(["RUNNING", "HALT"]); }
    }
  }
  const text = JSON.stringify(d, null, pick([0, 2, "\t"]));
  A.check(`doc #${i} ${text.length > 160 ? text.slice(0, 160) + "..." : text}`, text, docOk(JSON.parse(text)));
}
A.finish();
