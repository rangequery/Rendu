/* A02 - Cles dupliquees : le faux classique que JSON.parse avale (il garde la DERNIERE valeur)
 *   duplique chaque cle de chaque objet, avant/apres l'originale, avec la cle ecrite en clair,
 *   en \u minuscule, en \u MAJUSCULE, partiellement echappee, avec espaces avant ':'
 *   + faux positifs : textes qui CONTIENNENT des cles, guillemets, accolades, antislash final */
"use strict";
const { Agent, BASE, OBJECTS, textWith } = require("./lib");
const A = new Agent("A02 Doublons", "chaque cle de chaque objet dupliquee sous 5 deguisements, avant et apres l'originale");

function ser(o, p, inj) {
  if (o === null || typeof o !== "object") return JSON.stringify(o);
  const parts = Object.entries(o).map(([k, v]) => JSON.stringify(k) + ":" + ser(v, p ? `${p}.${k}` : k, inj));
  if (inj && inj.obj === p) parts.splice(inj.at, 0, inj.raw);
  return "{" + parts.join(",") + "}";
}
const hex = (c, up) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0")[up ? "toUpperCase" : "toLowerCase"]();
const encodings = (k) => ({
  clair: JSON.stringify(k),
  u_minuscule: '"' + [...k].map((c) => hex(c, false)).join("") + '"',
  u_majuscule: '"' + [...k].map((c) => hex(c, true)).join("") + '"',
  partiel: '"' + hex(k[0], false) + k.slice(1) + '"',
  espaces: JSON.stringify(k) + " \t\n ",
});
const base = BASE();
for (const obj of OBJECTS) {
  const o = obj === "" ? base : obj.split(".").reduce((x, k) => x[k], base);
  const keys = Object.keys(o);
  for (const k of keys) {
    for (const [enc, rawKey] of Object.entries(encodings(k))) {
      for (const val of [JSON.stringify(o[k]), '"brulant"', "null"]) {
        for (const at of [0, keys.length]) {
          A.check(`${obj || "(racine)"}.${k} duplique (${enc}, valeur ${val.slice(0, 20)}, position ${at ? "apres" : "avant"})`,
            ser(base, "", { obj, at, raw: `${rawKey}:${val}` }), false);
        }
      }
    }
  }
}
// Faux positifs : ces JSON sont VALIDES, le scanner ne doit pas voir de doublon
for (const [p, v] of [["location.address", '"temperature": 25, "light": 1'], ["location.address", "{\"status\": [1, {\"a\": 2}]}"],
  ["info.user", "GM\\"], ["info.ident", "ESP\\\"32"], ["location.address", "a:b,c{d}[e]\"f\""], ["info.loc", "\\\\"]]) {
  A.check(`${p} = ${JSON.stringify(v)} (pas un doublon)`, textWith(p, v), true);
}
A.check("meme nom dans 2 objets differents (status.regul et regul) : pas un doublon", textWith("info.user", "GM"), true);
A.finish();
