/* A08 - Nombres tels qu'ECRITS : JSON.parse arrondit en silence. On verifie que :
 *   - toute ecriture produite par un vrai serialiseur passe (JS, Python, ArduinoJson, printf
 *     %.Nf / %.Ng / %e, notation exposant, zeros de fin) ;
 *   - toute ecriture "trop precise", sous-depassement ou depassement est refusee ;
 *   - 1.5e2 est bien un entier (150) et 4095.5 non (valeur, pas ecriture).                    */
"use strict";
const { Agent, rawWith, rnd, rint } = require("./lib");
const A = new Agent("A08 Nombres", "ecritures legitimes de serialiseurs reels vs nombres forges pour etre arrondis en silence");
const L = [
  ["status.temperature", "25.9375", 1], ["status.temperature", "2.59375e1", 1], ["status.temperature", "2.59375E+1", 1],
  ["status.temperature", "259375e-4", 1], ["status.temperature", "25.93750000", 1], ["status.temperature", "0.259375e2", 1],
  ["status.temperature", "-0", 1], ["status.temperature", "-0.0", 1], ["status.temperature", "0e0", 1], ["status.temperature", "0E+00", 1],
  ["status.temperature", "25.9375" + "0".repeat(3000), 1], ["status.temperature", "125", 1], ["status.temperature", "1.25e2", 1],
  ["status.temperature", "125.00000000000001", 0], ["status.temperature", "25.93750000000000000000001", 0],
  ["status.temperature", "1e-400", 0], ["status.temperature", "-1e-400", 0], ["status.temperature", "0." + "0".repeat(400) + "1", 0],
  ["status.temperature", "1e999", 0], ["status.temperature", "-1e999", 0], ["status.temperature", "1" + "0".repeat(400), 0],
  ["status.temperature", "025", 0], ["status.temperature", "+25", 0], ["status.temperature", ".5", 0], ["status.temperature", "5.", 0],
  ["status.temperature", "1e", 0], ["status.temperature", "1e+", 0], ["status.temperature", "0x19", 0], ["status.temperature", "NaN", 0],
  ["status.temperature", "Infinity", 0], ["status.temperature", "25,9375", 0], ["status.temperature", "1_000", 0], ["status.temperature", "- 5", 0],
  ["status.light", "123", 1], ["status.light", "123.0", 1], ["status.light", "1.23e2", 1], ["status.light", "1.5e2", 1], ["status.light", "12300e-2", 1],
  ["status.light", "4.095e3", 1], ["status.light", "4.0951e3", 0], ["status.light", "123.5", 0], ["status.light", "123.000000000000000001", 0],
  ["status.light", "4095.0000000000000001", 0], ["status.light", "4095.00000000000001", 0], ["status.light", "-0", 1], ["status.light", "1e0000000000000000002", 1],
  ["reporthost.target_port", "1880.0", 1], ["reporthost.target_port", "1.88e3", 1], ["reporthost.target_port", "65535", 1], ["reporthost.target_port", "65535.0000000000001", 0],
  ["location.gps.lat", "43.62453842", 1], ["location.gps.lat", "43.6245384200000004", 1], ["location.gps.lat", "43.624538420000000", 1],
  ["location.gps.lat", "43.62453842000000037160134525038301944732666015625", 1], ["location.gps.lat", "43.6245384200000017", 0],
  ["location.gps.lat", "43.624538420000002", 0], ["location.gps.lat", "43.6245384200000001", 0], ["location.gps.lat", "90.000000000000001", 0], ["location.gps.lat", "90", 1],
];
for (const [f, raw, exp] of L) A.check(`${f} ecrit ${raw.length > 40 ? raw.slice(0, 37) + "..." : raw}`, rawWith(f, raw), exp === 1);
// Ecritures produites par de vrais outils pour des doubles aleatoires : toutes doivent passer
const printfF = (x, n) => x.toFixed(n);
for (let i = 0; i < 1500; i++) {
  const x = rnd(-55, 125);
  const forms = [String(x), x.toPrecision(rint(1, 40)), x.toExponential(rint(0, 30)), printfF(x, rint(0, 20)), JSON.stringify(Math.fround(x)), Math.fround(x).toPrecision(9)];
  for (const raw of forms) {
    const v = Number(raw);
    A.check(`temperature ecrite ${raw}`, rawWith("status.temperature", raw), v >= -55 && v <= 125);
  }
  const t = x.toPrecision(17);
  if (!t.includes("e")) {
    const forged = t + "000000000000001";
    A.check(`temperature forgee ${forged}`, rawWith("status.temperature", forged), Number(forged).toPrecision(32).replace(/0+$/, "") === forged.replace(/0+$/, ""));
  }
}
A.finish();
