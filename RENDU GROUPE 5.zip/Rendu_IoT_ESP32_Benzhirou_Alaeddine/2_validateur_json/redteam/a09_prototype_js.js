/* A09 - Pieges propres a JavaScript : __proto__, constructor, toString... comme cles en trop,
 *   a la place d'une cle obligatoire, ou dans les valeurs. Verifie aussi qu'aucune pollution
 *   de Object.prototype ne survit et que le validateur fonctionne encore apres l'attaque.     */
"use strict";
const { V, Agent, BASE, OBJECTS, clone } = require("./lib");
const A = new Agent("A09 Prototype JS", "__proto__ / constructor / toString... partout + controle de pollution apres coup");
const KEYS = ["__proto__", "constructor", "prototype", "toString", "valueOf", "hasOwnProperty", "__defineGetter__", "isPrototypeOf", "__lookupGetter__"];
const T = JSON.stringify(BASE());
for (const obj of OBJECTS) {
  for (const k of KEYS) {
    const at = obj === "" ? "{" : `"${obj.split(".").pop()}":{`;
    A.check(`${obj || "(racine)"} + cle "${k}"`, T.replace(at, `${at}"${k}":{"polluted":true,"fire":true},`), false);
  }
}
for (const k of KEYS) {
  for (const [field, val] of [["fire", "true"], ["temperature", "25.9375"], ["room", '"312"']]) {
    A.check(`"${field}" remplace par "${k}"`, T.replace(`"${field}":${val}`, `"${k}":${val}`), false);
  }
}
A.check("valeur objet avec __proto__", T.replace('"fire":true', '"fire":{"__proto__":{"valueOf":1}}'), false);
A.check("apres l'attaque, l'instance du prof passe toujours", T, true);
if ({}.polluted !== undefined || Object.prototype.fire !== undefined) A.crashes.push("Object.prototype a ete pollue !");
const d = clone(BASE());
delete d.status.fire;
A.check("apres l'attaque, un champ manquant est toujours detecte", JSON.stringify(d), false);
A.finish();
