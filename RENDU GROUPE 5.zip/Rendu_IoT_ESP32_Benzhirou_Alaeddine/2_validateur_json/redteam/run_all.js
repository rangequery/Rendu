#!/usr/bin/env node
/* run_all.js - Lance tous les agents EN PARALLELE (un processus chacun) et produit
 *   un rapport : console + redteam/RAPPORT_REDTEAM.md (a montrer au prof).
 *   Usage : npm run redteam                                                                  */
"use strict";
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const agents = fs.readdirSync(__dirname).filter((f) => /^a\d\d_.*\.js$/.test(f)).sort();
const t0 = Date.now();
const runOne = (f) => new Promise((resolve) => {
  const p = spawn(process.execPath, [path.join(__dirname, f), "--json"]);
  let out = "", err = "";
  p.stdout.on("data", (d) => (out += d));
  p.stderr.on("data", (d) => (err += d));
  p.on("close", (code) => {
    try { resolve(JSON.parse(out)); } catch { resolve({ name: f, mission: "?", attacks: 0, fakesPassed: [], falseRejects: [], crashes: [`agent plante (code ${code}) : ${err.slice(0, 300)}`], infos: [], maxMs: 0 }); }
  });
});
Promise.all(agents.map(runOne)).then((res) => {
  const tot = { a: 0, f: 0, r: 0, c: 0 };
  const lines = [];
  const md = ["# Rapport red team - validateur JSON ESP32", "", `Date : ${new Date().toISOString()}  `, `Agents : ${res.length}, lances en parallele`, "",
    "| Agent | Mission | Attaques | Faux acceptes | Faux rejets | Crashs | Pire temps |", "|---|---|---:|---:|---:|---:|---:|"];
  for (const r of res) {
    tot.a += r.attacks; tot.f += r.fakesPassed.length; tot.r += r.falseRejects.length; tot.c += r.crashes.length;
    const ok = !r.fakesPassed.length && !r.falseRejects.length && !r.crashes.length;
    lines.push(`${ok ? "\u2705" : "\u274C"} ${r.name.padEnd(30)} ${String(r.attacks).padStart(6)} attaques | faux acceptes ${String(r.fakesPassed.length).padStart(4)} | faux rejets ${String(r.falseRejects.length).padStart(4)} | crashs ${String(r.crashes.length).padStart(3)} | ${r.maxMs} ms`);
    md.push(`| ${ok ? "OK" : "**ECHEC**"} ${r.name} | ${r.mission} | ${r.attacks} | ${r.fakesPassed.length} | ${r.falseRejects.length} | ${r.crashes.length} | ${r.maxMs} ms |`);
  }
  console.log(lines.join("\n"));
  console.log(`\nTOTAL : ${tot.a} attaques | faux acceptes ${tot.f} | faux rejets ${tot.r} | crashs ${tot.c} | ${((Date.now() - t0) / 1000).toFixed(1)} s`);
  md.push(`| **TOTAL** | | **${tot.a}** | **${tot.f}** | **${tot.r}** | **${tot.c}** | |`, "");
  for (const r of res) {
    const det = [["Faux acceptes", r.fakesPassed], ["Faux rejets", r.falseRejects], ["Crashs", r.crashes], ["Infos", r.infos]].filter(([, l]) => l.length);
    if (!det.length) continue;
    md.push(`## ${r.name}`, "");
    for (const [t, l] of det) {
      md.push(`**${t}** (${l.length})`, "");
      for (const x of l.slice(0, 25)) md.push(`- \`${x.replace(/`/g, "'").replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufe00-\ufe0f\ufeff]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0"))}\``);
      if (l.length > 25) md.push(`- ... et ${l.length - 25} autres`);
      md.push("");
    }
  }
  fs.writeFileSync(path.join(__dirname, "RAPPORT_REDTEAM.md"), md.join("\n"));
  for (const r of res) {
    for (const [t, l] of [["FAUX ACCEPTE", r.fakesPassed], ["FAUX REJET", r.falseRejects], ["CRASH", r.crashes]])
      for (const x of l.slice(0, 4)) console.log(`   ${r.name.slice(0, 3)} ${t} : ${x.slice(0, 150)}`);
  }
  process.exit(tot.f + tot.r + tot.c ? 1 : 0);
});
