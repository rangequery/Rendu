# Rapport red team - validateur JSON ESP32

Date : 2026-10-28T09:20:00.602Z  
Agents : 13, lances en parallele

| Agent | Mission | Attaques | Faux acceptes | Faux rejets | Crashs | Pire temps |
|---|---|---:|---:|---:|---:|---:|
| OK A01 Syntaxe RFC 8259 | corpus officiel JSONTestSuite : 318 JSON pieges (mal formes, bien formes, ambigus) | 318 | 0 | 0 | 0 | 0 ms |
| OK A02 Doublons | chaque cle de chaque objet dupliquee sous 5 deguisements, avant et apres l'originale | 907 | 0 | 0 | 0 | 116.1 ms |
| OK A03 Types & structure | 23 champs x 34 valeurs de tous types + objets amputes/gonfles/remplaces | 925 | 0 | 0 | 0 | 82.6 ms |
| OK A04 Bornes | chaque borne testee au double IEEE 754 pres (valeur limite et voisine immediate) | 171 | 0 | 0 | 0 | 114.9 ms |
| OK A05 Formats reseau | IPv4 / IP cible / MAC / uptime : pieges connus + 16 000 chaines aleatoires | 16113 | 0 | 0 | 0 | 124.5 ms |
| OK A06 Unicode | 65 536 caracteres du BMP + plans supplementaires, homoglyphes, invisibles, zalgo, NFKC | 73336 | 0 | 0 | 0 | 100.3 ms |
| OK A07 Encodage & transport | fichiers forges octet par octet : UTF-8 invalide, UTF-16/32, BOM, NUL, espaces exotiques, taille limite | 34 | 0 | 0 | 0 | 219 ms |
| OK A08 Nombres | ecritures legitimes de serialiseurs reels vs nombres forges pour etre arrondis en silence | 10559 | 0 | 0 | 0 | 177.4 ms |
| OK A09 Prototype JS | __proto__ / constructor / toString... partout + controle de pollution apres coup | 102 | 0 | 0 | 0 | 245 ms |
| OK A10 Differentiel | 25 000 documents mutes au hasard, verdict compare a un oracle independant | 25000 | 0 | 0 | 0 | 217.2 ms |
| OK A11 Coherence | 16 combinaisons regul/heat/cold/fire, regles actives puis desactivees | 32 | 0 | 0 | 0 | 150.1 ms |
| OK A12 Charge / deni de service | entrees pathologiques : temps max 250 ms par validation | 13 | 0 | 0 | 0 | 488.5 ms |
| OK A13 API & CLI | entrees non textuelles, fichiers speciaux, dossiers vides, options, stdin geant | 27 | 0 | 0 | 0 | 0 ms |
| **TOTAL** | | **127537** | **0** | **0** | **0** | |

## A01 Syntaxe RFC 8259

**Infos** (3)

- `y_object_duplicated_key.json : bien forme, refuse volontairement par la couche DOUBLON`
- `y_object_duplicated_key_and_value.json : bien forme, refuse volontairement par la couche DOUBLON`
- `i_* (libres selon la RFC) -> 9 NOMBRE, 3 SCHEMA, 10 UNICODE, 13 ENCODAGE`

## A12 Charge / deni de service

**Infos** (13)

- `tableaux imbriques sur 16 Ko : 89.6 ms`
- `objets imbriques sur 16 Ko : 27.8 ms`
- `1500 cles en trop : 87.2 ms`
- `1500 fois la meme cle : 0.0 ms`
- `ReDoS texte : 15 000 caracteres puis un piege : 1.7 ms`
- `ReDoS texte : 15 000 accents combinants : 1.3 ms`
- `ReDoS MAC : 15 000 caracteres hexa : 1.0 ms`
- `ReDoS IP : 15 000 caracteres : 0.8 ms`
- `nombre de 15 000 chiffres : 0.2 ms`
- `decimal de 15 000 chiffres : 0.2 ms`
- `cle en trop de 15 000 caracteres (suggestion orthographique) : 1.0 ms`
- `16 Ko d'espaces avant le JSON : 0.0 ms`
- `debit : 1657 validations/s`
