/* A01 - Conformite RFC 8259 sur le corpus officiel JSONTestSuite (N. Seriot, licence MIT)
 *   n_*.json : JSON mal formes  -> doivent mourir a la lecture (LECTURE / ENCODAGE / SYNTAXE)
 *   y_*.json : JSON bien formes -> ne doivent PAS etre refuses par le parseur
 *   i_*.json : laisses libres par la RFC -> on documente notre choix                       */
"use strict";
const fs = require("fs");
const path = require("path");
const { V, Agent } = require("./lib");
const A = new Agent("A01 Syntaxe RFC 8259", "corpus officiel JSONTestSuite : 318 JSON pieges (mal formes, bien formes, ambigus)");
const DIR = path.join(__dirname, "corpus", "jsontestsuite");
const PARSE = new Set(["LECTURE", "ENCODAGE", "SYNTAXE"]);
const iStats = {};
for (const f of fs.readdirSync(DIR).filter((x) => x.endsWith(".json")).sort()) {
  A.attacks++;
  let r;
  try { r = V.validateBuffer(fs.readFileSync(path.join(DIR, f))); } catch (e) { A.crashes.push(`${f} -> ${e.message}`); continue; }
  if (r.errors.some((e) => e.layer === "INTERNE")) { A.crashes.push(f); continue; }
  const layer = r.valid ? "VALIDE" : r.errors[0].layer;
  if (f.startsWith("n_")) {
    if (!PARSE.has(layer)) A.fakesPassed.push(`${f} : mal forme mais accepte par le parseur (couche atteinte : ${layer})`);
  } else if (f.startsWith("y_")) {
    if (PARSE.has(layer)) A.falseRejects.push(`${f} -> [${layer}] ${r.errors[0].message}`);
    else if (layer !== "SCHEMA") A.info(`${f} : bien forme, refuse volontairement par la couche ${layer}`);
  } else {
    iStats[layer] = (iStats[layer] || 0) + 1;
  }
}
A.info(`i_* (libres selon la RFC) -> ${Object.entries(iStats).map(([k, v]) => `${v} ${k}`).join(", ")}`);
A.finish();
