/* A12 - Deni de service : entrees concues pour faire ramer ou exploser le validateur
 *   (imbrication extreme, milliers de cles, ReDoS sur les regex, nombres geants, 20 Mo via l'API).
 *   Chaque validation doit rester sous 250 ms, sinon c'est compte comme un crash.              */
"use strict";
const { V, Agent, BASE } = require("./lib");
const A = new Agent("A12 Charge / deni de service", "entrees pathologiques : temps max 250 ms par validation");
const T = JSON.stringify(BASE());
// meilleur de 3 essais : les autres agents tournent en parallele et faussent un essai isole
const timed = (label, input, expectValid) => {
  let best = Infinity;
  for (let k = 0; k < 3; k++) {
    const t0 = process.hrtime.bigint();
    if (k === 0) A.check(label, input, expectValid); else V.validateText(input);
    best = Math.min(best, Number(process.hrtime.bigint() - t0) / 1e6);
  }
  if (best > 250) A.crashes.push(`${label} -> ${best.toFixed(0)} ms (trop lent)`);
  else A.info(`${label} : ${best.toFixed(1)} ms`);
};
timed("tableaux imbriques sur 16 Ko", T.replace("{", '{"x":' + "[".repeat(7900) + "]".repeat(7900) + ","), false);
timed("objets imbriques sur 16 Ko", T.replace("{", '{"x":' + '{"a":'.repeat(2500) + "1" + "}".repeat(2500) + ","), false);
timed("1500 cles en trop", T.replace("{", "{" + Array.from({ length: 1500 }, (_, i) => `"k${i}":1`).join(",") + ","), false);
timed("1500 fois la meme cle", T.replace('"fire":true', Array.from({ length: 1500 }, () => '"fire":true').join(",")), false);
timed("ReDoS texte : 15 000 caracteres puis un piege", T.replace('"Les lucioles"', JSON.stringify("a ".repeat(7400) + "\u0000")), false);
timed("ReDoS texte : 15 000 accents combinants", T.replace('"Les lucioles"', JSON.stringify("e" + "\u0301".repeat(7000))), false);
timed("ReDoS MAC : 15 000 caracteres hexa", T.replace('"AC:67:B2:37:C9:48"', JSON.stringify("AC:".repeat(5000))), false);
timed("ReDoS IP : 15 000 caracteres", T.replace('"192.168.1.45"', JSON.stringify("1.".repeat(7000) + "x")), false);
timed("nombre de 15 000 chiffres", T.replace('"light":123', '"light":1' + "0".repeat(15000)), false);
timed("decimal de 15 000 chiffres", T.replace('"temperature":25.9375', '"temperature":25.' + "9".repeat(15000)), false);
timed("cle en trop de 15 000 caracteres (suggestion orthographique)", T.replace("{", `{"${"temperature".repeat(1300)}":1,`), false);
timed("16 Ko d'espaces avant le JSON", " ".repeat(16000) + T, false);
const t0 = Date.now();
const r = V.validateText(T + " ".repeat(20 * 1024 * 1024));
A.attacks++;
if (r.valid) A.fakesPassed.push("20 Mo via validateText() acceptes");
if (Date.now() - t0 > 250) A.crashes.push(`20 Mo via validateText() : ${Date.now() - t0} ms (aucune limite de taille dans l'API)`);
if (r.valid || r.errors[0].layer !== "LECTURE") A.crashes.push("20 Mo via validateText() : pas de limite de taille appliquee (couche " + (r.valid ? "VALIDE" : r.errors[0].layer) + ")");
const t1 = Date.now();
for (let i = 0; i < 3000; i++) V.validateText(T);
A.info(`debit : ${Math.round(3000 / ((Date.now() - t1) / 1000))} validations/s`);
A.finish();
