/* A04 - Bornes numeriques au double pres : min, max, et le double IMMEDIATEMENT voisin
 *   (nextUp/nextDown), demi-entiers, -0, extremes IEEE 754, entiers non surs (> 2^53) */
"use strict";
const { Agent, CONTRACT, LEAVES, leafOk, textWith } = require("./lib");
const A = new Agent("A04 Bornes", "chaque borne testee au double IEEE 754 pres (valeur limite et voisine immediate)");
function nextUp(x) {
  if (x === 0) return Number.MIN_VALUE;
  const dv = new DataView(new ArrayBuffer(8));
  dv.setFloat64(0, x);
  dv.setBigInt64(0, dv.getBigInt64(0) + (x > 0 ? 1n : -1n));
  return dv.getFloat64(0);
}
const nextDown = (x) => -nextUp(-x);
for (const leaf of LEAVES) {
  const s = CONTRACT[leaf];
  if (s.kind !== "number" && s.kind !== "integer") continue;
  const vals = [s.min, s.max, nextDown(s.min), nextUp(s.max), nextUp(s.min), nextDown(s.max), s.min - 1, s.max + 1,
    (s.min + s.max) / 2, s.min + 0.5, s.max - 0.5, -0, 1e308, -1e308, Number.MAX_SAFE_INTEGER, 2 ** 53 + 2, 5e-324, -5e-324, Math.PI];
  for (const v of vals) A.check(`${leaf} = ${v}`, textWith(leaf, v), leafOk(s, v));
}
A.finish();
