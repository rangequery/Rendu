/* A11 - Coherence : les 16 combinaisons regul x heat x cold x fire, avec et sans les regles */
"use strict";
const { Agent, BASE, docOk } = require("./lib");
const A = new Agent("A11 Coherence", "16 combinaisons regul/heat/cold/fire, regles actives puis desactivees");
for (const regul of ["RUNNING", "HALT"]) for (const heat of ["ON", "OFF"]) for (const cold of ["ON", "OFF"]) for (const fire of [true, false]) {
  const d = BASE();
  Object.assign(d.status, { regul, heat, cold, fire });
  const t = JSON.stringify(d);
  A.check(`regul=${regul} heat=${heat} cold=${cold} fire=${fire}`, t, docOk(d));
  A.check(`(sans coherence) regul=${regul} heat=${heat} cold=${cold} fire=${fire}`, t, docOk(d, { coherence: false }), { options: { coherence: false } });
}
A.finish();
