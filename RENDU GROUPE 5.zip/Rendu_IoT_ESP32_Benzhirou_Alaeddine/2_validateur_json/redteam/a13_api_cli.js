/* A13 - API (pour le serveur du TP5) et ligne de commande : entrees qui ne sont pas du texte,
 *   fichiers speciaux Unix (/dev/urandom, /dev/zero, FIFO), dossier vide, options inconnues,
 *   entree standard geante. Rien ne doit bloquer, planter ou repondre "valide" a tort.       */
"use strict";
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");
const { V, Agent, BASE } = require("./lib");
const A = new Agent("A13 API & CLI", "entrees non textuelles, fichiers speciaux, dossiers vides, options, stdin geant");
const T = JSON.stringify(BASE());
const api = (label, fn, expectValid) => {
  A.attacks++;
  let r;
  try { r = fn(); } catch (e) { A.crashes.push(`${label} -> exception ${e.message}`); return; }
  if (!r || typeof r.valid !== "boolean") { A.crashes.push(`${label} -> resultat invalide`); return; }
  if (r.errors.some((e) => e.layer === "INTERNE")) A.crashes.push(`${label} -> erreur INTERNE : ${r.errors[0].message}`);
  else if (r.valid && !expectValid) A.fakesPassed.push(label);
  else if (!r.valid && expectValid) A.falseRejects.push(`${label} -> ${r.errors[0].message}`);
};
for (const [label, x] of [["null", null], ["undefined", undefined], ["nombre 42", 42], ["objet {}", {}], ["tableau", []], ["String objet", new String(T)], ["Symbol", Symbol("x")]])
  api(`validateText(${label})`, () => V.validateText(x), false);
api("validateText(Buffer valide)", () => V.validateText(Buffer.from(T)), true);
api("validateText(texte avec BOM)", () => V.validateText("\uFEFF" + T), true);
api("validateBuffer(chaine)", () => V.validateBuffer(T), false);
api("validateBuffer(null)", () => V.validateBuffer(null), false);
api("validateFile(dossier)", () => V.validateFile(os.tmpdir()), false);
api("validateFile(inexistant)", () => V.validateFile("/nexiste/pas.json"), false);

const CLI = path.join(__dirname, "..", "validate.js");
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "redteam-"));
fs.writeFileSync(path.join(tmp, "ok.json"), T);
fs.writeFileSync(path.join(tmp, "ko.json"), T.replace('"fire":true', '"fire":"true"'));
fs.mkdirSync(path.join(tmp, "vide"));
fs.mkdirSync(path.join(tmp, "maj"));
fs.writeFileSync(path.join(tmp, "maj", "STATUS.JSON"), T.replace('"fire":true', '"fire":1'));
const cli = (label, args, expectedCode, input) => {
  A.attacks++;
  const r = spawnSync(process.execPath, [CLI, ...args], { input, timeout: 6000, maxBuffer: 1 << 26 });
  // EPIPE = le validateur a raccroche apres 16 Ko au lieu d'avaler les 20 Mo : c'est voulu
  if (r.signal || (r.error && !(r.error.code === "EPIPE" && r.status !== null))) { A.crashes.push(`${label} -> bloque / tue (${r.error ? r.error.code : r.signal})`); return; }
  if (r.status === expectedCode) return;
  const msg = `${label} -> code ${r.status} (attendu ${expectedCode})`;
  if (r.status === 0) A.fakesPassed.push(msg); else if (expectedCode === 0) A.falseRejects.push(msg); else A.crashes.push(msg);
};
cli("fichier valide", [path.join(tmp, "ok.json")], 0);
cli("fichier invalide", [path.join(tmp, "ko.json")], 1);
cli("valide + invalide", [path.join(tmp, "ok.json"), path.join(tmp, "ko.json")], 1);
cli("sans argument", [], 2);
cli("dossier vide (aucun JSON a valider)", [path.join(tmp, "vide")], 2);
cli("option inconnue --foo", ["--foo", path.join(tmp, "ok.json")], 2);
cli("dossier avec STATUS.JSON en majuscules (invalide)", [path.join(tmp, "maj")], 1);
cli("--sans-coherence apres le fichier", [path.join(tmp, "ok.json"), "--sans-coherence"], 0);
cli("stdin valide", ["-"], 0, T);
cli("stdin 20 Mo", ["-"], 1, T + " ".repeat(20 * 1024 * 1024));
for (const dev of ["/dev/urandom", "/dev/zero", "/dev/null"]) if (fs.existsSync(dev)) cli(dev, [dev], 1);
const fifo = path.join(tmp, "tube.json");
if (spawnSync("mkfifo", [fifo]).status === 0) cli("FIFO (tube nomme, personne n'ecrit)", [fifo], 1);
fs.rmSync(tmp, { recursive: true, force: true });
A.finish();
