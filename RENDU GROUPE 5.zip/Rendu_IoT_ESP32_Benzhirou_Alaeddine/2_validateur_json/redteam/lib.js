/*
 * lib.js - Outils communs aux agents d'attaque
 *
 * Chaque agent a un "oracle" : une re-ecriture INDEPENDANTE du contrat (CONTRACT + fonctions
 * ci-dessous), codee a la main SANS reutiliser esp_schema.json ni Ajv. Si l'oracle et le
 * validateur ne sont pas d'accord, l'un des deux a un bug : c'est ce qu'on cherche.
 */
"use strict";
const path = require("path");
const V = require(path.join(__dirname, "..", "validate.js"));

/* ---------- Instance de reference (slide 28, syntaxe corrigee) ---------- */
const BASE = () => ({
  status: { temperature: 25.9375, light: 123, regul: "HALT", fire: true, heat: "OFF", cold: "OFF", fanspeed: 1234 },
  location: { room: "312", gps: { lat: 43.62453842, lon: 7.050628185 }, address: "Les lucioles" },
  regul: { lt: 26, ht: 25.89999962 },
  info: { ident: "ESP32 123", user: "GM", loc: "A Biot" },
  net: { uptime: "55", ssid: "Livebox-B870", mac: "AC:67:B2:37:C9:48", ip: "192.168.1.45" },
  reporthost: { target_ip: "127.0.0.1", target_port: 1880, sp: 2 },
});
const clone = (o) => JSON.parse(JSON.stringify(o));
const OBJECTS = ["", "status", "location", "location.gps", "regul", "info", "net", "reporthost"];

/* ---------- Le contrat, re-ecrit a la main ---------- */
const CELSIUS = { kind: "number", min: -55, max: 125 };
const CONTRACT = {
  "status.temperature": CELSIUS,
  "status.light": { kind: "integer", min: 0, max: 4095 },
  "status.regul": { kind: "enum", values: ["RUNNING", "HALT"] },
  "status.fire": { kind: "boolean" },
  "status.heat": { kind: "enum", values: ["ON", "OFF"] },
  "status.cold": { kind: "enum", values: ["ON", "OFF"] },
  "status.fanspeed": { kind: "integer", min: 0, max: 65535 },
  "location.room": { kind: "text", maxBytes: 49 },
  "location.gps.lat": { kind: "number", min: -90, max: 90 },
  "location.gps.lon": { kind: "number", min: -180, max: 180 },
  "location.address": { kind: "text", maxBytes: 199 },
  "regul.lt": CELSIUS,
  "regul.ht": CELSIUS,
  "info.ident": { kind: "text", maxBytes: 49 },
  "info.user": { kind: "text", maxBytes: 49 },
  "info.loc": { kind: "text", maxBytes: 49 },
  "net.uptime": { kind: "uptime" },
  "net.ssid": { kind: "text", maxBytes: 32 },
  "net.mac": { kind: "mac" },
  "net.ip": { kind: "ipv4" },
  "reporthost.target_ip": { kind: "ipv4", target: true },
  "reporthost.target_port": { kind: "integer", min: 1, max: 65535 },
  "reporthost.sp": { kind: "integer", min: 1, max: 3600 },
};
const LEAVES = Object.keys(CONTRACT);

/* ---------- Oracles (code volontairement different du schema) ---------- */
function ipv4Ok(s, target) {
  if (typeof s !== "string") return false;
  const parts = s.split(".");
  if (parts.length !== 4) return false;
  const nums = [];
  for (const p of parts) {
    if (p.length < 1 || p.length > 3) return false;
    for (const ch of p) if (ch < "0" || ch > "9") return false;
    if (p.length > 1 && p[0] === "0") return false;
    const n = Number(p);
    if (n > 255) return false;
    nums.push(n);
  }
  if (target) {
    if (nums.every((n) => n === 0) || nums.every((n) => n === 255)) return false;
    if (nums[0] >= 224 && nums[0] <= 239) return false;
  }
  return true;
}
function macOk(s) {
  if (typeof s !== "string") return false;
  const parts = s.split(":");
  if (parts.length !== 6) return false;
  for (const p of parts) {
    if (p.length !== 2) return false;
    for (const ch of p) if (!"0123456789abcdefABCDEF".includes(ch)) return false;
  }
  const up = s.toUpperCase();
  return up !== "00:00:00:00:00:00" && up !== "FF:FF:FF:FF:FF:FF";
}
function uptimeOk(s) {
  if (typeof s !== "string" || s.length < 1 || s.length > 10) return false;
  for (const ch of s) if (ch < "0" || ch > "9") return false;
  return s === "0" || s[0] !== "0";
}
// Politique texte : lettres latines (accents compris), chiffres ASCII, ponctuation, symboles,
// espace simple ; pas d'espace en bord ; pas d'invisible ; forme NFKC = NFC ; accents combinants
// uniquement apres une lettre, 2 max d'affilee ; taille en octets UTF-8.
function textOk(s, maxBytes) {
  if (typeof s !== "string" || s.length === 0) return false;
  if (Buffer.byteLength(s, "utf8") > maxBytes) return false;
  if (s.startsWith(" ") || s.endsWith(" ")) return false;
  if (s.normalize("NFKC") !== s.normalize("NFC")) return false;
  let baseIsLetter = false;
  let marks = 0;
  for (const ch of s) {
    const cp = ch.codePointAt(0);
    if (cp >= 0xd800 && cp <= 0xdfff) return false;           // surrogate isole
    if (cp === 0xfffd || cp === 0x2800) return false;         // remplacement, braille vide
    if (/\p{Default_Ignorable_Code_Point}/u.test(ch)) return false;
    if (/\p{M}/u.test(ch)) {
      if (!baseIsLetter || marks >= 2) return false;
      marks++;
      continue;
    }
    marks = 0;
    if (cp === 0x20) { baseIsLetter = false; continue; }
    if (/\p{L}/u.test(ch)) {
      if (!/\p{Script=Latin}/u.test(ch)) return false;
      baseIsLetter = true;
      continue;
    }
    baseIsLetter = false;
    if (/\p{N}/u.test(ch)) { if (cp < 0x30 || cp > 0x39) return false; continue; }
    if (/[\p{P}\p{S}]/u.test(ch)) continue;
    return false; // C*, Z* (sauf espace simple), Cn...
  }
  return true;
}
function leafOk(spec, v) {
  switch (spec.kind) {
    case "number": return typeof v === "number" && Number.isFinite(v) && v >= spec.min && v <= spec.max;
    case "integer": return typeof v === "number" && Number.isInteger(v) && v >= spec.min && v <= spec.max;
    case "boolean": return typeof v === "boolean";
    case "enum": return typeof v === "string" && spec.values.includes(v);
    case "text": return textOk(v, spec.maxBytes);
    case "uptime": return uptimeOk(v);
    case "mac": return macOk(v);
    case "ipv4": return ipv4Ok(v, spec.target);
    default: throw new Error("kind inconnu " + spec.kind);
  }
}
const isPlainObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
// Oracle complet sur un objet deja lu (structure fermee + feuilles + coherence)
function docOk(doc, { coherence = true } = {}) {
  const expectedKeys = {};
  for (const leaf of LEAVES) {
    const parts = leaf.split(".");
    for (let i = 0; i < parts.length; i++) {
      const parent = parts.slice(0, i).join(".");
      (expectedKeys[parent] = expectedKeys[parent] || new Set()).add(parts[i]);
    }
  }
  for (const objPath of OBJECTS) {
    const o = objPath === "" ? doc : objPath.split(".").reduce((x, k) => (isPlainObject(x) && own(x, k) ? x[k] : undefined), doc);
    if (!isPlainObject(o)) return false;
    const keys = Object.keys(o);
    if (keys.length !== expectedKeys[objPath].size) return false;
    for (const k of keys) if (!expectedKeys[objPath].has(k)) return false;
  }
  for (const leaf of LEAVES) {
    const v = leaf.split(".").reduce((x, k) => x[k], doc);
    if (!leafOk(CONTRACT[leaf], v)) return false;
  }
  if (coherence) {
    const s = doc.status;
    if (s.heat === "ON" && s.cold === "ON") return false;
    if (s.regul === "HALT" && (s.heat === "ON" || s.cold === "ON")) return false;
  }
  return true;
}

/* ---------- Construction d'attaques ---------- */
function setPath(o, p, v) {
  const ks = p.split(".");
  let x = o;
  for (const k of ks.slice(0, -1)) x = x[k];
  x[ks[ks.length - 1]] = v;
  return o;
}
const docWith = (p, v) => setPath(clone(BASE()), p, v);
const textWith = (p, v, indent = 2) => JSON.stringify(docWith(p, v), null, indent);
// Injecte un fragment BRUT (tel quel dans le fichier) a la place de la valeur d'un champ
const rawWith = (p, raw) => textWith(p, "@@RAW@@").replace('"@@RAW@@"', () => raw);

/* ---------- Rapport ---------- */
class Agent {
  constructor(name, mission) {
    this.name = name;
    this.mission = mission;
    this.attacks = 0;
    this.fakesPassed = [];   // faux ACCEPTES (le pire)
    this.falseRejects = [];  // vrais REJETES
    this.crashes = [];       // exceptions / erreurs internes
    this.infos = [];
    this.maxMs = 0;
  }
  check(label, input, expectValid, { buffer = false, options } = {}) {
    this.attacks++;
    let r;
    const t0 = process.hrtime.bigint();
    try {
      r = buffer ? V.validateBuffer(input, options) : V.validateText(input, options);
    } catch (e) {
      this.crashes.push(`${label} -> exception ${e.message}`);
      return null;
    }
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    if (ms > this.maxMs) this.maxMs = ms;
    if (r.errors.some((e) => e.layer === "INTERNE")) this.crashes.push(`${label} -> ${r.errors[0].message}`);
    else if (!expectValid && r.valid) this.fakesPassed.push(label);
    else if (expectValid && !r.valid) this.falseRejects.push(`${label} -> [${r.errors[0].layer}] ${r.errors[0].path} ${r.errors[0].message}`);
    return r;
  }
  info(msg) { this.infos.push(msg); }
  finish() {
    const res = {
      name: this.name, mission: this.mission, attacks: this.attacks,
      fakesPassed: this.fakesPassed, falseRejects: this.falseRejects, crashes: this.crashes,
      infos: this.infos, maxMs: Math.round(this.maxMs * 10) / 10,
    };
    if (process.argv.includes("--json")) process.stdout.write(JSON.stringify(res));
    else {
      const ok = !res.fakesPassed.length && !res.falseRejects.length && !res.crashes.length;
      console.log(`${ok ? "\u2705" : "\u274C"} ${res.name} : ${res.attacks} attaques | faux acceptes ${res.fakesPassed.length} | faux rejets ${res.falseRejects.length} | crashs ${res.crashes.length} | pire temps ${res.maxMs} ms`);
      for (const [t, list] of [["FAUX ACCEPTE", res.fakesPassed], ["FAUX REJET", res.falseRejects], ["CRASH", res.crashes]])
        for (const x of list.slice(0, 12)) console.log(`   ${t} : ${x}`);
      for (const x of res.infos) console.log(`   info : ${x}`);
    }
    return res;
  }
}

/* ---------- Generateur de documents valides aleatoires ---------- */
const rnd = (a, b) => a + Math.random() * (b - a);
const rint = (a, b) => Math.floor(rnd(a, b + 1));
const pick = (a) => a[rint(0, a.length - 1)];
const WORDS = ["Les lucioles", "Résidence Newton", "Bât. B — 2e étage", "A Biot", "Sophia-Antipolis", "GM", "Alae",
  "ESP32 123", "Livebox-B870", "NOP", "salle 312", "Labo I3S (Templiers)", "Ç’est l’été ☀", "Salle 3°C", "Crème brûlée"];
function randomValidDoc() {
  const heat = pick(["ON", "OFF"]);
  const cold = heat === "ON" ? "OFF" : pick(["ON", "OFF"]);
  const regul = heat === "ON" || cold === "ON" ? "RUNNING" : pick(["RUNNING", "HALT"]);
  const hex = () => rint(0, 255).toString(16).padStart(2, "0");
  let mac;
  do mac = Array.from({ length: 6 }, hex).join(":"); while (!macOk(mac));
  const ip = () => [rint(0, 255), rint(0, 255), rint(0, 255), rint(0, 255)].join(".");
  let tip;
  do tip = ip(); while (!ipv4Ok(tip, true));
  return {
    status: { temperature: rnd(-55, 125), light: rint(0, 4095), regul, fire: Math.random() < 0.5, heat, cold, fanspeed: rint(0, 65535) },
    location: { room: pick(WORDS), gps: { lat: rnd(-90, 90), lon: rnd(-180, 180) }, address: pick(WORDS) },
    regul: { lt: rnd(-55, 125), ht: rnd(-55, 125) },
    info: { ident: pick(WORDS), user: pick(WORDS), loc: pick(WORDS) },
    net: { uptime: String(rint(0, 4e9)), ssid: pick(WORDS), mac: Math.random() < 0.5 ? mac.toUpperCase() : mac, ip: ip() },
    reporthost: { target_ip: tip, target_port: rint(1, 65535), sp: rint(1, 3600) },
  };
}

module.exports = { V, BASE, clone, OBJECTS, CONTRACT, LEAVES, leafOk, textOk, ipv4Ok, macOk, uptimeOk, docOk,
  setPath, docWith, textWith, rawWith, Agent, rnd, rint, pick, randomValidDoc };
