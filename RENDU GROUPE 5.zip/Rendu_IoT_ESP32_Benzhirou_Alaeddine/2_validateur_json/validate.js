#!/usr/bin/env node
/*
 * validate.js - Validateur "blinde" du status JSON de l'ESP32 (modele G. Menez)
 *
 * Usage :
 *   node validate.js fichier.json [autre.json] [dossier/] ...
 *   npm test                         -> lance toute la batterie de tests/
 *
 * Code retour : 0 = tout est valide | 1 = au moins un JSON invalide | 2 = mauvaise utilisation
 *
 * 5 couches de controle, dans l'ordre :
 *   1. LECTURE  : fichier existant, lisible, taille max 16 Ko
 *   2. ENCODAGE : UTF-8 strict (octets invalides, UTF-16, octet nul refuses) ; BOM tolere avec avertissement
 *   3. SYNTAXE  : JSON.parse (RFC 8259) -> virgules, guillemets, zeros initiaux, NaN, commentaires...
 *   4. TEXTE BRUT, ce que JSON.parse avale EN SILENCE :
 *        - DOUBLON : cles dupliquees ("a":"x","a":1 -> garde la derniere), meme deguisees en \u0061
 *        - NOMBRE  : 1e999 -> Infinity, 1e-400 -> 0, 123.000000000000000001 -> 123 (precision perdue)
 *        - UNICODE : surrogates UTF-16 isoles (\uD800 seul), interdits par I-JSON (RFC 7493)
 *   5. SCHEMA   : Ajv / JSON Schema 2020-12 -> structure, types, valeurs, formats, coherence
 *
 * Principe : "fail closed". Le moindre doute ou la moindre exception = INVALIDE.
 *
 * Options CLI :
 *   -                 lit le JSON sur l'entree standard  (ex : cat status.json | node validate.js -)
 *   --sans-coherence  desactive les 2 regles de coherence heat/cold/regul (voir README)
 *
 * Reutilisable (TP5, serveur) :
 *   const { validateText } = require("./validate");
 *   const r = validateText(chaineRecue);                       // { valid, errors, warnings }
 *   const r2 = validateText(chaineRecue, { coherence: false }); // sans les regles de coherence
 */
"use strict";

const fs = require("fs");
const path = require("path");
const Ajv2020 = require("ajv/dist/2020");
const addFormats = require("ajv-formats");

const SCHEMA = require("./esp_schema.json");
const MAX_BYTES = 16 * 1024; // un status ESP fait ~500 octets

/* ------------------------------------------------------------------ */
/*  Ajv : configuration la plus stricte possible                       */
/* ------------------------------------------------------------------ */
const ajv = new Ajv2020({
  allErrors: true,     // toutes les erreurs, pas seulement la premiere
  strict: true,        // refuse un schema ambigu ou avec un mot-cle inconnu
  coerceTypes: false,  // "25" ne devient JAMAIS 25, "true" ne devient JAMAIS true
  useDefaults: false,  // aucune valeur ajoutee en douce
  ownProperties: true, // "required" ne regarde que les vraies proprietes (pas le prototype JS)
  verbose: true,       // donne la donnee fautive + le sous-schema (messages precis)
});
addFormats(ajv, ["ipv4"]);

// Les buffers C (char room[50]...) se mesurent en OCTETS : "e accent" = 2 octets en UTF-8
ajv.addKeyword({
  keyword: "maxBytes",
  type: "string",
  schemaType: "number",
  validate: (max, data) => Buffer.byteLength(data, "utf8") <= max,
});

// Caracteres de "compatibilite" : pleine chasse (ＧＭ), lettres mathematiques (𝐆𝐌), exposants (m²),
// ligatures (ﬁ), chiffres romains (Ⅻ)... : leur forme NFKC differe de leur forme NFC
ajv.addKeyword({
  keyword: "nfkc",
  type: "string",
  schemaType: "boolean",
  validate: (on, data) => !on || data.normalize("NFKC") === data.normalize("NFC"),
});

const checkFull = ajv.compile(SCHEMA);
const RELAXED = JSON.parse(JSON.stringify(SCHEMA));
RELAXED.$id += ":sans-coherence";
delete RELAXED.properties.status.allOf;
const checkRelaxed = ajv.compile(RELAXED);

/* ------------------------------------------------------------------ */
/*  Outils                                                             */
/* ------------------------------------------------------------------ */
const joinPath = (base, key) => (base ? `${base}.${key}` : String(key));

function pointerToPath(ptr) {
  if (!ptr) return "(racine)";
  return ptr
    .split("/")
    .slice(1)
    .map((s) => s.replace(/~1/g, "/").replace(/~0/g, "~"))
    .join(".");
}

function show(v) {
  if (typeof v === "number") return String(v);
  let s = JSON.stringify(v);
  if (s === undefined) return String(v);
  // caracteres non-ASCII rendus visibles : "H\u0410LT" (A cyrillique) au lieu de "HALT"
  s = s.replace(/[^\x20-\x7E]/gu, (c) => {
    const cp = c.codePointAt(0);
    return cp > 0xffff ? `\\u{${cp.toString(16).toUpperCase()}}` : "\\u" + cp.toString(16).padStart(4, "0").toUpperCase();
  });
  return s.length > 45 ? s.slice(0, 42) + "..." : s;
}

const hasHiddenChar = (v) => typeof v === "string" && /[^\x20-\x7E]/.test(v);

// Surrogate UTF-16 isole (moitie de caractere) : texte Unicode invalide
const LONE_SURROGATE = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/;

// Forme canonique d'un nombre decimal : "1880.0", "1.88e3", "0001880" -> "188e4"
function canonDecimal(str) {
  let t = str.toLowerCase();
  const neg = t.startsWith("-");
  if (neg) t = t.slice(1);
  const [mant, e = "0"] = t.split("e");
  const [ip, fp = ""] = mant.split(".");
  let digits = ip + fp;
  let exp = Number(e) + ip.length;
  const stripped = digits.replace(/^0+/, "");
  exp -= digits.length - stripped.length;
  digits = stripped.replace(/0+$/, "");
  if (!digits) return "0";
  return (neg ? "-" : "") + digits + "e" + exp;
}

// Valeur EXACTE du double lu, en decimal : |x| = 0.DIGITS x 10^exp (calcul exact en BigInt)
function exactDecimal(x) {
  const dv = new DataView(new ArrayBuffer(8));
  dv.setFloat64(0, Math.abs(x));
  const bits = dv.getBigUint64(0);
  const expBits = Number((bits >> 52n) & 0x7ffn);
  const frac = bits & ((1n << 52n) - 1n);
  const m = expBits === 0 ? frac : frac | (1n << 52n);
  const e = expBits === 0 ? -1074 : expBits - 1075;
  const n = e >= 0 ? (m << BigInt(e)).toString() : (m * 5n ** BigInt(-e)).toString();
  return { digits: n, exp: n.length + (e >= 0 ? 0 : e) };
}

// Le nombre ECRIT est-il un arrondi correct de la valeur reellement lue ?
// Oui pour toute sortie d'un vrai serialiseur (JS, Python, ArduinoJson, printf %.Nf / %.Ng / %e,
// zeros de fin...). Non pour 123.000000000000000001 (lu 123), 1e-400 (lu 0) : precision perdue.
function isExactNumber(token) {
  const x = Number(token);
  if (!Number.isFinite(x)) return true; // Infinity : signale par ailleurs
  const c = canonDecimal(token);
  if (x === 0) return c === "0";
  if (c === "0") return false;
  const neg = c.startsWith("-");
  if (neg !== x < 0) return false;
  const [D, E] = (neg ? c.slice(1) : c).split("e");
  const L = D.length;
  const ex = exactDecimal(x);
  const candidates = [];
  if (ex.digits.length <= L) candidates.push({ digits: ex.digits, exp: ex.exp });
  else {
    const head = ex.digits.slice(0, L);
    const tail = ex.digits.slice(L);
    const up = () => {
      const h = (BigInt(head) + 1n).toString();
      return h.length > L ? { digits: h.slice(0, L), exp: ex.exp + 1 } : { digits: h, exp: ex.exp };
    };
    if (tail[0] > "5" || (tail[0] === "5" && /[1-9]/.test(tail.slice(1)))) candidates.push(up());
    else if (tail[0] < "5") candidates.push({ digits: head, exp: ex.exp });
    else candidates.push({ digits: head, exp: ex.exp }, up()); // egalite parfaite : les 2 arrondis sont admis
  }
  return candidates.some((r) => r.digits.replace(/0+$/, "") === D && r.exp === Number(E));
}

function jsonType(v) {
  if (v === null) return "null";
  if (Array.isArray(v)) return "array";
  if (typeof v === "number") return Number.isInteger(v) ? "integer" : "number";
  return typeof v;
}

const TYPE_FR = {
  number: "un nombre",
  integer: "un entier",
  string: "une chaine",
  boolean: "un booleen (true/false)",
  object: "un objet {...}",
  array: "un tableau [...]",
  null: "null",
};

function levenshtein(a, b) {
  if (a.length > 64 || b.length > 64) return Infinity; // une cle de 15 000 caracteres n'est pas une faute de frappe
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1,
        d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}

function suggest(key, allowed) {
  let best = null;
  let bestD = 3;
  for (const a of allowed) {
    const d = a.toLowerCase() === key.toLowerCase() ? 0 : levenshtein(key, a);
    if (d < bestD) { bestD = d; best = a; }
  }
  return best;
}

/* ------------------------------------------------------------------ */
/*  Couche 2 : encodage                                                */
/* ------------------------------------------------------------------ */
function decodeUtf8Strict(buf, warnings) {
  if ((buf[0] === 0xff && buf[1] === 0xfe) || (buf[0] === 0xfe && buf[1] === 0xff)) {
    throw new Error("fichier encode en UTF-16 : un JSON doit etre en UTF-8 (RFC 8259)");
  }
  const nul = buf.indexOf(0);
  if (nul !== -1) {
    throw new Error(`octet nul (0x00) a l'octet ${nul} : interdit en JSON (fin de chaine C ? UTF-16 ?)`);
  }
  return new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(buf);
}

/* ------------------------------------------------------------------ */
/*  Couche 3 : syntaxe                                                 */
/* ------------------------------------------------------------------ */
function syntaxMessage(text, err) {
  let msg = err.message;
  const m = /position (\d+)/.exec(msg);
  if (m && !/line \d+/.test(msg)) {
    const before = text.slice(0, Number(m[1]));
    const line = before.split("\n").length;
    const col = before.length - before.lastIndexOf("\n");
    msg += ` (ligne ${line}, colonne ${col})`;
  }
  if (text.trim() === "") return "fichier vide (aucun JSON)";
  return "JSON mal forme : " + msg;
}

/* ------------------------------------------------------------------ */
/*  Couche 4 : scan du texte brut (doublons + nombres tels qu'ecrits)  */
/*  JSON.parse('{"a":"x","a":1}') donne {a:1} sans broncher : c'est    */
/*  LE moyen classique de faire passer un faux. On rescanne le texte.  */
/*  Appele uniquement sur un texte deja syntaxiquement valide.         */
/* ------------------------------------------------------------------ */
function scanRaw(text) {
  const duplicates = [];
  const numbers = []; // { path, token } : le nombre tel qu'ECRIT dans le fichier
  const stack = [];   // { kind: "obj"|"arr", path, keys, key, index }
  const WS = " \t\n\r";
  const NUM = /-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/y;
  const childPath = () => {
    const top = stack[stack.length - 1];
    if (!top) return "";
    return top.kind === "obj" ? joinPath(top.path, top.key) : `${top.path}[${top.index}]`;
  };
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (c === '"') {
      let j = i + 1;
      while (text[j] !== '"') j += text[j] === "\\" ? 2 : 1;
      let k = j + 1;
      while (k < text.length && WS.includes(text[k])) k++;
      const top = stack[stack.length - 1];
      if (top && top.kind === "obj" && text[k] === ":") {
        // on decode la cle : "temp\u0065rature" et "temperature" sont LA MEME cle
        const key = JSON.parse(text.slice(i, j + 1));
        if (top.keys.has(key)) duplicates.push({ path: top.path, key });
        top.keys.add(key);
        top.key = key;
      }
      i = j + 1;
      continue;
    }
    if (c === "-" || (c >= "0" && c <= "9")) {
      NUM.lastIndex = i;
      const token = NUM.exec(text)[0];
      numbers.push({ path: childPath() || "(racine)", token });
      i += token.length;
      continue;
    }
    if (c === "{" || c === "[") {
      stack.push({ kind: c === "{" ? "obj" : "arr", path: childPath(), keys: new Set(), key: null, index: 0 });
    } else if (c === "}" || c === "]") {
      stack.pop();
    } else if (c === ",") {
      const top = stack[stack.length - 1];
      if (top && top.kind === "arr") top.index++;
    }
    i++;
  }
  return { duplicates, numbers };
}

/* ------------------------------------------------------------------ */
/*  Parcours de la valeur lue : nombres infinis + surrogates isoles     */
/*  Parcours iteratif : pas de recursion -> pas de crash sur [[[[...]]]] */
/* ------------------------------------------------------------------ */
function walkValues(root) {
  const nonFinite = [];
  const surrogates = [];
  const todo = [[root, ""]];
  while (todo.length) {
    const [v, p] = todo.pop();
    if (typeof v === "number" && !Number.isFinite(v)) nonFinite.push(p || "(racine)");
    else if (typeof v === "string" && LONE_SURROGATE.test(v)) surrogates.push(p || "(racine)");
    else if (v !== null && typeof v === "object") {
      for (const k of Object.keys(v)) {
        if (LONE_SURROGATE.test(k)) surrogates.push(`${p || "(racine)"} (cle ${show(k)})`);
        todo.push([v[k], Array.isArray(v) ? `${p}[${k}]` : joinPath(p, k)]);
      }
    }
  }
  return { nonFinite, surrogates };
}

/* ------------------------------------------------------------------ */
/*  Couche 5 : schema -> messages en francais                          */
/* ------------------------------------------------------------------ */
function schemaMessage(e) {
  const p = e.params;
  const desc = e.parentSchema && e.parentSchema.description;
  switch (e.keyword) {
    case "required":
      return `champ obligatoire manquant : ${show(p.missingProperty)}`;
    case "additionalProperties": {
      const allowed = Object.keys((e.parentSchema && e.parentSchema.properties) || {});
      const s = suggest(p.additionalProperty, allowed);
      return `champ non autorise : ${show(p.additionalProperty)}` + (s ? ` (vouliez-vous dire "${s}" ?)` : " (absent du modele)");
    }
    case "type":
    {
      const t = jsonType(e.data);
      const scalar = t !== "null" && t !== "object" && t !== "array";
      return `type incorrect : attendu ${TYPE_FR[p.type] || p.type}, recu ${TYPE_FR[t]}` + (scalar ? ` ${show(e.data)}` : "");
    }
    case "enum":
      return `valeur interdite ${show(e.data)} : valeurs possibles ${p.allowedValues.map(show).join(" | ")}` +
        (hasHiddenChar(e.data) ? " (contient un caractere non-ASCII deguise)" : "");
    case "const":
      return `doit valoir ${show(p.allowedValue)}, recu ${show(e.data)}`;
    case "minimum":
    case "maximum":
    case "exclusiveMinimum":
    case "exclusiveMaximum":
      return `${show(e.data)} hors limites : doit etre ${p.comparison} ${p.limit}` + (desc ? ` (${desc})` : "");
    case "minLength":
      return `texte trop court : minimum ${p.limit} caractere(s)`;
    case "maxLength":
      return `texte trop long : ${[...e.data].length} caracteres, maximum ${p.limit} (taille du buffer C)`;
    case "pattern":
      return `format invalide ${show(e.data)}` + (desc ? ` : ${desc}` : "");
    case "maxBytes":
      return `texte trop long : ${Buffer.byteLength(e.data, "utf8")} octets en UTF-8, maximum ${e.schema} (buffer C char[${e.schema + 1}])`;
    case "format":
      return `format ${p.format} invalide : ${show(e.data)}`;
    case "nfkc":
      return `caractere de compatibilite dans ${show(e.data)} (pleine chasse, lettre/chiffre mathematique, exposant, ligature...) : ecrire la forme normale ${show(e.data.normalize("NFKC"))}`;
    case "not":
    case "if":
      return desc || e.message;
    default:
      return e.message;
  }
}

function runSchema(value, coherence) {
  const check = coherence ? checkFull : checkRelaxed;
  if (check(value)) return [];
  let errs = check.errors.filter((e) => !e.schemaPath.includes("/then/")); // resume par l'erreur "if"
  // une regle precise (invisible, homoglyphe, NFKC...) rend le motif generique redondant
  const precise = new Set(errs.filter((e) => e.keyword === "not" || e.keyword === "nfkc").map((e) => e.instancePath));
  errs = errs.filter((e) => !(e.keyword === "pattern" && precise.has(e.instancePath)));
  // maxLength (caracteres) et maxBytes (octets) disent la meme chose : on garde maxBytes
  const bytesFail = new Set(errs.filter((e) => e.keyword === "maxBytes").map((e) => e.instancePath));
  errs = errs.filter((e) => !(e.keyword === "maxLength" && bytesFail.has(e.instancePath)));
  // si le type est faux a un chemin, les autres erreurs a ce meme chemin ne sont que du bruit
  const typeFail = new Set(errs.filter((e) => e.keyword === "type").map((e) => e.instancePath));
  errs = errs.filter((e) => e.keyword === "type" || !typeFail.has(e.instancePath));
  const seen = new Set();
  const out = [];
  const MAX_REPORTED = 50; // au-dela, le JSON est de toute facon une poubelle : on resume
  const extra = errs.length - MAX_REPORTED;
  if (extra > 0) errs = errs.slice(0, MAX_REPORTED);
  for (const e of errs) {
    const item = { layer: "SCHEMA", path: pointerToPath(e.instancePath), message: schemaMessage(e) };
    const sig = item.path + "|" + item.message;
    if (!seen.has(sig)) { seen.add(sig); out.push(item); }
  }
  if (extra > 0) out.push({ layer: "SCHEMA", path: "", message: `... et ${extra} autres erreurs non detaillees` });
  return out;
}

/* ------------------------------------------------------------------ */
/*  API                                                                */
/* ------------------------------------------------------------------ */
function validateText(text, options = {}, warnings = []) {
  if (text instanceof Uint8Array) return validateBuffer(text, options); // ex. corps HTTP brut (TP5)
  if (typeof text !== "string") return reject("LECTURE", `entree invalide : une chaine de caracteres est attendue (recu ${text === null ? "null" : typeof text})`);
  if (text.length > MAX_BYTES || Buffer.byteLength(text, "utf8") > MAX_BYTES) return reject("LECTURE", `trop gros : plus de ${MAX_BYTES} octets`, warnings);
  if (text.charCodeAt(0) === 0xfeff) {
    warnings.push("BOM UTF-8 en debut de texte ignore (RFC 8259 l'autorise en lecture)");
    text = text.slice(1);
  }
  const coherence = options.coherence !== false;
  const errors = [];
  try {
    let value;
    try {
      value = JSON.parse(text);
    } catch (err) {
      errors.push({ layer: "SYNTAXE", path: "", message: syntaxMessage(text, err) });
      return { valid: false, errors, warnings };
    }
    const { duplicates, numbers } = scanRaw(text);
    for (const d of duplicates) {
      errors.push({
        layer: "DOUBLON",
        path: d.path || "(racine)",
        message: `cle ${show(d.key)} presente plusieurs fois dans le meme objet (JSON.parse ne garde que la derniere)`,
      });
    }
    const { nonFinite, surrogates } = walkValues(value);
    for (const p of nonFinite) {
      errors.push({ layer: "NOMBRE", path: p, message: "nombre trop grand : devient Infinity une fois lu" });
    }
    for (const n of numbers) {
      if (!isExactNumber(n.token)) {
        errors.push({
          layer: "NOMBRE",
          path: n.path,
          message: `${n.token.length > 30 ? n.token.slice(0, 27) + "..." : n.token} ne tient pas dans un double : lu comme ${Number(n.token)} (precision perdue en silence)`,
        });
      }
    }
    for (const p of surrogates) {
      errors.push({ layer: "UNICODE", path: p, message: "surrogate UTF-16 isole (moitie de caractere) : texte Unicode invalide (RFC 7493)" });
    }
    errors.push(...runSchema(value, coherence));
  } catch (err) {
    // fail closed : une erreur inattendue ne doit JAMAIS laisser passer un JSON
    errors.push({ layer: "INTERNE", path: "", message: `erreur inattendue -> rejet par securite (${err.message})` });
  }
  return { valid: errors.length === 0, errors, warnings };
}

const reject = (layer, message, warnings = []) => ({ valid: false, errors: [{ layer, path: "", message }], warnings });

function validateBuffer(buf, options = {}) {
  const warnings = [];
  if (!(buf instanceof Uint8Array)) return reject("LECTURE", "entree invalide : un Buffer d'octets est attendu");
  if (buf.length > MAX_BYTES) return reject("LECTURE", `trop gros : plus de ${MAX_BYTES} octets`);
  let text;
  try {
    text = decodeUtf8Strict(buf, warnings);
  } catch (err) {
    const msg = err instanceof TypeError ? "octets invalides : le fichier n'est pas de l'UTF-8 valide" : err.message;
    return { valid: false, errors: [{ layer: "ENCODAGE", path: "", message: msg }], warnings };
  }
  return validateText(text, options, warnings);
}

// Lit au plus MAX_BYTES + 1 octets : un fichier infini (/dev/urandom) ne peut pas bloquer
function readBounded(file) {
  const isStdin = file === "-";
  if (!isStdin) {
    const st = fs.statSync(file); // stat AVANT open : ouvrir une FIFO bloquerait
    if (!st.isFile()) throw Object.assign(new Error("pas un fichier normal (dossier, peripherique, tube...)"), { code: "NOT_A_FILE" });
  }
  const fd = isStdin ? 0 : fs.openSync(file, "r");
  try {
    const chunks = [];
    let total = 0;
    const chunk = Buffer.alloc(64 * 1024);
    for (let again = 0; total <= MAX_BYTES; ) {
      let n;
      try {
        n = fs.readSync(fd, chunk, 0, chunk.length, null);
      } catch (e) {
        if (e.code === "EAGAIN" && again++ < 1000) continue;
        if (e.code === "EOF") break;
        throw e;
      }
      if (n === 0) break;
      chunks.push(Buffer.from(chunk.subarray(0, n)));
      total += n;
    }
    return Buffer.concat(chunks);
  } finally {
    if (!isStdin) fs.closeSync(fd);
  }
}

function validateFile(file, options = {}) {
  let buf;
  try {
    buf = readBounded(file);
  } catch (err) {
    const why = err.code === "NOT_A_FILE" ? err.message : err.code || err.message;
    return { valid: false, errors: [{ layer: "LECTURE", path: "", message: `impossible de lire le fichier (${why})` }], warnings: [] };
  }
  return validateBuffer(buf, options);
}

// Echauffement : V8 compile les regex Unicode (\p{...}) a leur 1re utilisation (~100 ms)
validateText('{"status":{"temperature":25.9375,"light":123,"regul":"HALT","fire":true,"heat":"OFF","cold":"OFF","fanspeed":1234},"location":{"room":"312","gps":{"lat":43.62453842,"lon":7.050628185},"address":"Les lucioles"},"regul":{"lt":26,"ht":25.89999962},"info":{"ident":"ESP32 123","user":"GM","loc":"A Biot"},"net":{"uptime":"55","ssid":"Livebox-B870","mac":"AC:67:B2:37:C9:48","ip":"192.168.1.45"},"reporthost":{"target_ip":"127.0.0.1","target_port":1880,"sp":2}}');

/* ------------------------------------------------------------------ */
/*  CLI                                                                */
/* ------------------------------------------------------------------ */
function expandArgs(args) {
  const files = [];
  for (const a of args) {
    if (a !== "-" && fs.existsSync(a) && fs.statSync(a).isDirectory()) {
      fs.readdirSync(a).filter((f) => f.toLowerCase().endsWith(".json")).sort().forEach((f) => files.push(path.join(a, f)));
    } else files.push(a);
  }
  return files;
}

function printResult(file, r) {
  if (r.valid) console.log(`\u2705 ${file} : VALIDE`);
  else console.log(`\u274C ${file} : INVALIDE (${r.errors.length} erreur${r.errors.length > 1 ? "s" : ""})`);
  for (const w of r.warnings) console.log(`   \u26A0\uFE0F  ${w}`);
  for (const e of r.errors) {
    const where = e.path ? `${e.path} : ` : "";
    console.log(`   [${e.layer}] ${where}${e.message}`);
  }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const options = { coherence: !argv.includes("--sans-coherence") };
  const args = argv.filter((a) => a !== "--sans-coherence");
  const usage = "Usage : node validate.js [--sans-coherence] fichier.json [autre.json] [dossier/] [-]";
  const unknown = args.filter((a) => a.startsWith("--"));
  if (unknown.length) {
    console.error(`Option inconnue : ${unknown.join(" ")}\n${usage}`);
    process.exit(2);
  }
  if (args.length === 0) {
    console.error(usage);
    process.exit(2);
  }
  const files = expandArgs(args);
  if (files.length === 0) {
    console.error("Aucun fichier .json a valider (dossier vide ?) : rien n'a ete verifie.");
    process.exit(2);
  }
  let allValid = true;
  for (const f of files) {
    const r = validateFile(f, options);
    printResult(f === "-" ? "(entree standard)" : f, r);
    if (!r.valid) allValid = false;
  }
  process.exit(allValid ? 0 : 1);
}

module.exports = { validateText, validateBuffer, validateFile, SCHEMA, MAX_BYTES };
